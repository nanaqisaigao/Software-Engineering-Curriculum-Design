/**
 * 仓库包，此java package对应数据访问层，等同于DAO，jpa框架的repository配合data-rest提供restful方式的接口，可以简化开发
 *
 * @author zyp
 * @version 0.0.1
 * @since 0.0.1
 */
package sut.edu.zyp.dormitory.manage.repository;